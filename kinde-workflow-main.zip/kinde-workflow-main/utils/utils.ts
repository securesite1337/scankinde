const settings = {
    output: '123'
}

export {
    settings
}